from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def home(request):
    return render(request, "home.html",{"name":"Tanvii"})

def add(request):

    val1 = request.POST['firstname']
    val2 = request.POST['lastname']
    res = val1 + val2

    return render(request, 'result.html', {'result': res})
