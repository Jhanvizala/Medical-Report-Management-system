from django.contrib import admin
from .models import medical

# Register your models here.

admin.site.register(medical)