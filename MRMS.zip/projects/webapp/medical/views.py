from django.shortcuts import render
from .models import medical

# Create your views here.
def index(request):

    return render(request, "index.html")

def departments(request):

    return render(request, "departments.html")