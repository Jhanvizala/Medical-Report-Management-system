from django.db import models
# Create your models here.

class report(models.Model):
    read_img = models.CharField(max_length=10000,blank=True)
    username = models.CharField(max_length=100)
    report_type= models.CharField(max_length=100)
    cur_date = models.DateField()
    image = models.ImageField(upload_to='report/images/')
    
    

    def __str__(self):
        return self.username



class read(models.Model):
    username = models.CharField(max_length=100)
    read_img = models.ImageField(upload_to='report/images/')

    def __str__(self):
        self.username

