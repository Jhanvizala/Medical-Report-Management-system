from django.urls import path 
from  . import views
from .views import delete_report 

urlpatterns = [
    path('home', views.home, name='home'),
    path('contact', views.contact, name='contact'),
    path('about', views.about, name='about'),
    path('features', views.features, name='features'),
    path('register', views.register, name='register'),
    path('login', views.login, name="login"),
    path('logout', views.logout, name='logout'),
    path('departments', views.departments, name='departments'),
    path('image', views.image, name='image'),
    path('report/', views.report_list, name='report_list'),
    path('report/images', views.upload_report, name='upload_report'),
    path('report/<int:id>', views.delete_report, name='delete_report'),
    path('<id>/delete', views.delete_report, name='delete_report' ), 
    path('annual_report', views.annual_report, name='annual_report'),
]